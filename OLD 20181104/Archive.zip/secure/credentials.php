<?php

function getDbCreds(){
    return array(
        'host' => 'enhome.czsbom142yss.us-east-2.rds.amazonaws.com;dbname=enhome',
        'username' => 'johnsturdivant',
        'password' => 'Ross2200',
        'db' => 'enhome'
    );
}

function getGoogleCreds(){
    return array(
        'clientId' => '143581905454-b1c77r2ulhbvibc1olqmfrceb97e28r4.apps.googleusercontent.com',
        'clientSecret' => '6Go2dGGi5rQ87ndsW6nSUm3y'
    );
}


?>