<html>
    <head>
    <?php  include_once('functions.php'); ?>
    <script src='functions.js' ></script>
        <script>
            
        </script>
    </head>
    
<body onload=''>
         <?php print_r(getHeader('Home'));?>
    <div id='mainContent' class="container" > 
        
    
        <ul>
            <li><a href='/'>Home</a>
            <li><a href='app/'>App</a>
            <li><a href='app/users/logout.php'>Logout</a>
        </ul>
    </div>
   
</body> 
<script>        
</script>
</html>
