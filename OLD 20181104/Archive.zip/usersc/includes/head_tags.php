<!-- Facebook sharing meta tags (delete if you don't want them) -->
<meta property="og:url"                content="" /> <!-- URL for website (link address) -->
<meta property="og:type"               content="website" /> <!-- type of site -->
<meta property="og:title"              content="Userspice Site" /> <!-- title of site (title of share) -->
<meta property="og:description"        content="Userspice Site Description" /> <!-- description of site (text which appears when sharing) -->
<meta property="og:image"              content="" /> <!-- URL for preview image -->	