<?php

include_once('../functions.php');

echo 'this is a test';

?>